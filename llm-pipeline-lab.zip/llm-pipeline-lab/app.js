const $ = s => document.querySelector(s);

/* ---------- Tabs ---------- */
document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.toggle('on', x === b));
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t.id === b.dataset.tab));
  if (b.dataset.tab === 'emb') { sizeCanvas(); draw(); }
});

/* ---------- 1. Byte-level BPE tokeniser (trained from scratch) ---------- */
const BASE_CORPUS = `The king and queen lived in the royal palace. The king was wise and the queen was kind.
Artificial intelligence and machine learning are changing how people write software. A neural network learns patterns from data.
Tokenization splits text into smaller pieces called tokens. Language models read tokens, not words. Embeddings turn tokens into vectors of numbers.
The quick brown fox jumps over the lazy dog. People eat apple pie and drink tea in the morning.
def add(a, b): return a + b. for i in range(10): print(i). The model predicts the next token in the sequence.
Students walked into the library while the teacher analyzed the results. Walking, talking, running and jumping are common words.
Transformers use attention to understand the relationship between words in a sentence. Training a tokenizer means counting frequent pairs and merging them.`;
const SPLIT = /\s?\p{L}+|\s?\p{N}+|\s?[^\s\p{L}\p{N}]+|\s+/gu;
const utf8 = s => Array.from(new TextEncoder().encode(s));
const decoder = new TextDecoder();
let vocab = [], merges = [], ranks = new Map();

function train(corpus, n) {
  vocab = Array.from({ length: 256 }, (_, i) => [i]); merges = []; ranks = new Map();
  const freq = new Map();
  for (const w of corpus.match(SPLIT) || []) freq.set(w, (freq.get(w) || 0) + 1);
  const words = [...freq].map(([w, c]) => ({ ids: utf8(w), c }));
  for (let m = 0; m < n; m++) {
    const pc = new Map();
    for (const { ids, c } of words) for (let i = 0; i < ids.length - 1; i++) {
      const k = ids[i] + ',' + ids[i + 1]; pc.set(k, (pc.get(k) || 0) + c);
    }
    let best = null, bc = 1;
    for (const [k, c] of pc) if (c > bc) { best = k; bc = c; }
    if (!best) break;
    const [a, b] = best.split(',').map(Number), id = vocab.length;
    vocab.push([...vocab[a], ...vocab[b]]); merges.push([a, b]); ranks.set(best, { rank: m, id });
    for (const w of words) {
      const o = [];
      for (let i = 0; i < w.ids.length; i++) {
        if (i < w.ids.length - 1 && w.ids[i] === a && w.ids[i + 1] === b) { o.push(id); i++; } else o.push(w.ids[i]);
      }
      w.ids = o;
    }
  }
}
function encode(text) {
  const out = [];
  for (const w of text.match(SPLIT) || []) {
    const ids = utf8(w);
    while (ids.length > 1) {
      let br = Infinity, bi = -1, bid = 0;
      for (let i = 0; i < ids.length - 1; i++) {
        const r = ranks.get(ids[i] + ',' + ids[i + 1]);
        if (r && r.rank < br) { br = r.rank; bi = i; bid = r.id; }
      }
      if (bi < 0) break;
      ids.splice(bi, 2, bid);
    }
    out.push(...ids);
  }
  return out;
}
const tokStr = id => decoder.decode(new Uint8Array(vocab[id]));
const hue = id => (id * 47) % 360;
let ids = [], selTokIdx = -1;

function renderTokens() {
  const text = $('#text').value;
  ids = encode(text);
  const showIds = $('#ids').checked, sp = $('#spaces').checked;
  const box = $('#pills'); box.innerHTML = '';
  ids.forEach((id, i) => {
    const b = document.createElement('button');
    b.className = 'pill' + (i === selTokIdx ? ' sel' : '');
    b.style.background = `hsl(${hue(id)} 70% 85%)`;
    let s = tokStr(id); if (sp) s = s.replace(/ /g, '␣');
    b.textContent = s.replace(/\n/g, '↵');
    if (showIds) { const sm = document.createElement('small'); sm.textContent = id; b.appendChild(sm); }
    b.onclick = () => { selTokIdx = i; inspect(id); renderTokens(); };
    box.appendChild(b);
  });
  $('#sChars').textContent = text.length; $('#sToks').textContent = ids.length;
  $('#sRatio').textContent = ids.length ? (text.length / ids.length).toFixed(2) : '0';
  $('#sVocab').textContent = vocab.length;
  $('#idarr').textContent = '[' + ids.join(', ') + ']';
  buildEmbeddings();
}
function inspect(id) {
  const bytes = vocab[id].map(b => b.toString(16).padStart(2, '0')).join(' ');
  let how;
  if (id < 256) how = 'A single raw byte. Nothing in the training data made it worth merging into something bigger.';
  else { const [a, b] = merges[id - 256]; how = `Merge #${id - 255}: learned by joining token ${a} (${JSON.stringify(tokStr(a))}) and token ${b} (${JSON.stringify(tokStr(b))}) because that pair was frequent in the corpus.`; }
  $('#insp').innerHTML = '';
  const p = document.createElement('div');
  p.textContent = `Text: ${JSON.stringify(tokStr(id))}\nID: ${id}\nBytes (hex): ${bytes}\n${how}`;
  p.style.whiteSpace = 'pre-wrap'; p.style.fontFamily = "'IBM Plex Mono',monospace"; p.style.fontSize = '13px';
  $('#insp').appendChild(p);
}
function retrain() {
  $('#retrain').disabled = true;
  setTimeout(() => {
    train(BASE_CORPUS + '\n' + $('#corpus').value + '\n' + $('#text').value, +$('#merges').value || 0);
    selTokIdx = -1; renderTokens(); $('#retrain').disabled = false;
  }, 10);
}
$('#corpus').value = BASE_CORPUS;
$('#retrain').onclick = retrain;
$('#text').oninput = renderTokens; $('#ids').onchange = renderTokens; $('#spaces').onchange = renderTokens;

/* ---------- 2. Embedding system + PCA to 3D ---------- */
const D = 64;
function fnv(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const gramCache = new Map();
function gram(k) {
  if (!gramCache.has(k)) { const r = rng(fnv(k)), v = new Float32Array(D); for (let i = 0; i < D; i++) v[i] = r() + r() + r() - 1.5; gramCache.set(k, v); }
  return gramCache.get(k);
}
function subwordVec(s) {
  const t = '<' + s.trim().toLowerCase() + '>', v = new Float32Array(D);
  const add = g => { const x = gram(g); for (let j = 0; j < D; j++) v[j] += x[j]; };
  for (let n = 3; n <= 5; n++) for (let i = 0; i + n <= t.length; i++) add(t.slice(i, i + n));
  add(t);
  return v;
}
const norm = v => { let s = 0; for (const x of v) s += x * x; s = Math.sqrt(s) || 1; return v.map(x => x / s); };
const cos = (a, b) => { let s = 0; for (let i = 0; i < D; i++) s += a[i] * b[i]; return s; };

let pts = []; // {id,label,vec,x,y,z}
function buildEmbeddings() {
  const uniq = [...new Set(ids)];
  const base = new Map(uniq.map(id => [id, subwordVec(tokStr(id))]));
  const acc = new Map(uniq.map(id => [id, { v: new Float32Array(D), n: 0 }]));
  ids.forEach((id, i) => {
    const a = acc.get(id), ctx = new Float32Array(D); let c = 0;
    for (const d of [-2, -1, 1, 2]) { const j = i + d; if (j >= 0 && j < ids.length) { const b = base.get(ids[j]); for (let k = 0; k < D; k++) ctx[k] += b[k]; c++; } }
    const own = base.get(id);
    for (let k = 0; k < D; k++) a.v[k] += own[k] + (c ? 0.5 * ctx[k] / c : 0);
    a.n++;
  });
  pts = uniq.map(id => ({ id, label: tokStr(id).replace(/ /g, '␣'), vec: norm(acc.get(id).v) }));
  pca3();
  const opts = pts.map((p, i) => `<option value="${i}"></option>`).join('');
  for (const s of ['#ca', '#cb']) { const el = $(s); el.innerHTML = opts; [...el.options].forEach((o, i) => o.textContent = pts[i].label); }
  if (pts.length > 1) $('#cb').selectedIndex = 1;
  compare(); selPt = -1; $('#sel').textContent = 'Click a point.'; $('#nn').innerHTML = '';
  draw();
}
function pca3() {
  const n = pts.length; if (!n) return;
  const mean = new Float32Array(D); pts.forEach(p => p.vec.forEach((x, k) => mean[k] += x / n));
  let X = pts.map(p => Float32Array.from(p.vec, (x, k) => x - mean[k]));
  const comps = [];
  for (let c = 0; c < 3; c++) {
    let v = Float32Array.from({ length: D }, (_, k) => Math.sin(k * 12.9 + c * 4.1) + 0.1);
    for (let it = 0; it < 40; it++) {
      const w = new Float32Array(D);
      for (const r of X) { let d = 0; for (let k = 0; k < D; k++) d += r[k] * v[k]; for (let k = 0; k < D; k++) w[k] += d * r[k]; }
      v = norm(w);
    }
    comps.push(v);
    X = X.map(r => { let d = 0; for (let k = 0; k < D; k++) d += r[k] * v[k]; return Float32Array.from(r, (x, k) => x - d * v[k]); });
  }
  const raw = pts.map(p => comps.map(v => { let d = 0; for (let k = 0; k < D; k++) d += (p.vec[k] - mean[k]) * v[k]; return d; }));
  const sc = [0, 1, 2].map(a => Math.max(1e-6, ...raw.map(r => Math.abs(r[a]))));
  pts.forEach((p, i) => { p.x = raw[i][0] / sc[0]; p.y = raw[i][1] / sc[1]; p.z = raw[i][2] / sc[2]; });
}
function compare() {
  const a = pts[$('#ca').selectedIndex], b = pts[$('#cb').selectedIndex];
  $('#cres').textContent = a && b ? 'cosine: ' + cos(a.vec, b.vec).toFixed(3) : 'cosine: -';
}
$('#ca').onchange = $('#cb').onchange = compare;

/* tiny 3D renderer on canvas */
const cv = $('#cv'), cx = cv.getContext('2d');
let ax = 0.4, ay = 0.6, zoom = 1, selPt = -1, proj = [];
function sizeCanvas() { const r = cv.getBoundingClientRect(), d = devicePixelRatio || 1; cv.width = r.width * d; cv.height = r.height * d; cx.setTransform(d, 0, 0, d, 0, 0); }
function project(x, y, z) {
  const cy = Math.cos(ay), sy = Math.sin(ay), cxx = Math.cos(ax), sx = Math.sin(ax);
  let X = x * cy + z * sy, Z = -x * sy + z * cy, Y = y * cxx - Z * sx; Z = y * sx + Z * cxx;
  const W = cv.getBoundingClientRect(), f = 3 / (3 + Z), s = Math.min(W.width, W.height) * 0.36 * zoom;
  return { px: W.width / 2 + X * s * f, py: W.height / 2 - Y * s * f, z: Z, f };
}
function draw() {
  const W = cv.getBoundingClientRect(); if (!W.width) return;
  cx.clearRect(0, 0, W.width, W.height);
  cx.strokeStyle = '#cfd4cc'; cx.lineWidth = 1;
  for (const [a, b] of [[[-1, 0, 0], [1, 0, 0]], [[0, -1, 0], [0, 1, 0]], [[0, 0, -1], [0, 0, 1]]]) {
    const p = project(...a), q = project(...b); cx.beginPath(); cx.moveTo(p.px, p.py); cx.lineTo(q.px, q.py); cx.stroke();
  }
  proj = pts.map((p, i) => ({ i, ...project(p.x, p.y, p.z) })).sort((a, b) => b.z - a.z);
  cx.font = "12px 'IBM Plex Mono',monospace";
  for (const q of proj) {
    const p = pts[q.i], r = 6 * q.f, on = q.i === selPt;
    cx.fillStyle = on ? '#c2410c' : `hsl(${hue(p.id)} 60% 45%)`;
    cx.beginPath(); cx.arc(q.px, q.py, on ? r + 3 : r, 0, 7); cx.fill();
    cx.fillStyle = '#1d2733'; cx.fillText(p.label, q.px + r + 4, q.py + 4);
  }
}
let drag = null;
cv.onpointerdown = e => { drag = { x: e.clientX, y: e.clientY, moved: false }; cv.setPointerCapture(e.pointerId); };
cv.onpointermove = e => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 2) drag.moved = true; ay += dx * 0.01; ax += dy * 0.01; drag.x = e.clientX; drag.y = e.clientY; draw(); };
cv.onpointerup = e => {
  if (drag && !drag.moved) {
    const r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top;
    let best = -1, bd = 18; for (const q of proj) { const d = Math.hypot(q.px - mx, q.py - my); if (d < bd) { bd = d; best = q.i; } }
    if (best >= 0) selectPoint(best);
  }
  drag = null;
};
cv.onwheel = e => { e.preventDefault(); zoom = Math.min(3, Math.max(0.4, zoom * (e.deltaY < 0 ? 1.1 : 0.9))); draw(); };
function selectPoint(i) {
  selPt = i; const p = pts[i];
  $('#sel').textContent = `${JSON.stringify(p.label)} (ID ${p.id}) at (${p.x.toFixed(2)}, ${p.y.toFixed(2)}, ${p.z.toFixed(2)})`;
  const rows = pts.map((q, j) => ({ j, c: cos(p.vec, q.vec) })).filter(r => r.j !== i).sort((a, b) => b.c - a.c).slice(0, 5);
  $('#nn').innerHTML = rows.map(r => `<tr><td></td><td style="text-align:right">${r.c.toFixed(3)}</td></tr>`).join('');
  [...$('#nn').rows].forEach((tr, k) => tr.cells[0].textContent = pts[rows[k].j].label);
  draw();
}
addEventListener('resize', () => { sizeCanvas(); draw(); });

/* ---------- 3. Groq playground ---------- */
const chat = $('#chat'); let history = [];
$('#temp').oninput = e => $('#tv').textContent = e.target.value;
$('#topp').oninput = e => $('#pv').textContent = e.target.value;
fetch('/api/models').then(r => r.json()).then(j => { $('#model').innerHTML = j.models.map(m => `<option>${m}</option>`).join(''); })
  .catch(() => { $('#model').innerHTML = '<option>llama-3.3-70b-versatile</option><option>llama-3.1-8b-instant</option>'; });
function bubble(role, text) {
  const d = document.createElement('div'); d.className = 'msg ' + role;
  const t = document.createElement('div'); t.textContent = text; d.appendChild(t);
  const m = document.createElement('div'); m.className = 'meta'; d.appendChild(m);
  chat.appendChild(d); chat.scrollTop = chat.scrollHeight; return { t, m };
}
async function send() {
  const prompt = $('#prompt').value.trim(); if (!prompt) return;
  $('#prompt').value = ''; $('#send').disabled = true;
  const u = bubble('user', prompt); u.m.textContent = `${encode(prompt).length} tokens`;
  history.push({ role: 'user', content: prompt });
  const a = bubble('assistant', ''); const t0 = performance.now(); let full = '';
  try {
    const messages = [{ role: 'system', content: $('#sys').value }, ...history];
    const r = await fetch('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: $('#model').value, messages, temperature: +$('#temp').value, top_p: +$('#topp').value, max_tokens: +$('#maxt').value }),
    });
    if (!r.ok) throw new Error((await r.text()).slice(0, 300));
    const rd = r.body.getReader(), dc = new TextDecoder(); let buf = '';
    for (;;) {
      const { done, value } = await rd.read(); if (done) break;
      buf += dc.decode(value, { stream: true });
      const lines = buf.split('\n'); buf = lines.pop();
      for (const l of lines) {
        if (!l.startsWith('data:') || l.includes('[DONE]')) continue;
        try { const c = JSON.parse(l.slice(5)).choices?.[0]?.delta?.content; if (c) { full += c; a.t.textContent = full; chat.scrollTop = chat.scrollHeight; } } catch {}
      }
    }
    history.push({ role: 'assistant', content: full });
    const n = encode(full).length, s = (performance.now() - t0) / 1000;
    a.m.textContent = `${n} tokens (our tokeniser) in ${s.toFixed(1)}s, ${(n / s).toFixed(0)} tok/s`;
  } catch (e) { a.t.textContent = 'Request failed: ' + e.message; a.t.className = 'err'; history.pop(); }
  $('#send').disabled = false;
}
$('#send').onclick = send;
$('#prompt').onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
$('#clear').onclick = () => { history = []; chat.innerHTML = ''; };

train(BASE_CORPUS + '\n' + $('#text').value, 300);
renderTokens();
