// Vercel serverless function: forwards chat requests to Groq and streams the reply back.
// The key lives ONLY in the GROQ_API_KEY environment variable, never in the browser.
module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Use POST' });
  if (!process.env.GROQ_API_KEY) return res.status(500).json({ error: 'GROQ_API_KEY is not set on the server' });
  const b = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
  const payload = {
    model: b.model || 'llama-3.3-70b-versatile',
    messages: b.messages || [],
    temperature: Number(b.temperature ?? 0.7),
    max_tokens: Math.min(Number(b.max_tokens ?? 512), 4096),
    top_p: Number(b.top_p ?? 1),
    stream: true,
  };
  try {
    const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
      body: JSON.stringify(payload),
    });
    if (!r.ok) return res.status(r.status).json({ error: await r.text() });
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    for await (const chunk of r.body) res.write(chunk);
    res.end();
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
};
