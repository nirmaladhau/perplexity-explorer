// Lists the chat models available on your Groq account.
module.exports = async (req, res) => {
  const fallback = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant'];
  if (!process.env.GROQ_API_KEY) return res.status(200).json({ models: fallback });
  try {
    const r = await fetch('https://api.groq.com/openai/v1/models', {
      headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
    });
    const j = await r.json();
    const models = (j.data || []).filter(m => m.active !== false && !/whisper|tts|guard|playai/i.test(m.id)).map(m => m.id).sort();
    res.status(200).json({ models: models.length ? models : fallback });
  } catch (e) {
    res.status(200).json({ models: fallback });
  }
};
