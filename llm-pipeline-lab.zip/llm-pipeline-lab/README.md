# LLM Pipeline Lab

Three parts in one app:

1. **Tokeniser**: a byte-level BPE tokeniser trained from scratch in `app.js` (count pairs, merge the most frequent, repeat).
2. **Embeddings**: each unique token becomes a 64-D vector (hashed character n-grams + neighbouring tokens), reduced to 3D with PCA and drawn on a canvas. Similarity here reflects shared spelling and context, not true meaning. For semantic vectors, swap `subwordVec` for a real model such as `transformers.js`.
3. **Playground**: a Groq-powered chat with model picker, temperature, top-p, max tokens, streaming, and token counts from your own tokeniser.

## Run locally
```
npm i -g vercel
cp .env.example .env.local   # then put your key in .env.local
vercel dev
```

## Deploy
1. Push this folder to GitHub (`.env*` files are git-ignored).
2. Import the repo on vercel.com.
3. Project Settings -> Environment Variables -> add `GROQ_API_KEY`, then redeploy.

The key is only read in `api/chat.js` and `api/models.js` on the server. Never paste it into `app.js` or commit it.
